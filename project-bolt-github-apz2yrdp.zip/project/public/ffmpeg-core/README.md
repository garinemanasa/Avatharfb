# FFmpeg Core Files

This directory should contain the FFmpeg core files:

1. `ffmpeg-core.js` - Download from: https://unpkg.com/@ffmpeg/core@0.12.16/dist/umd/ffmpeg-core.js
2. `ffmpeg-core.wasm` - Download from: https://unpkg.com/@ffmpeg/core@0.12.16/dist/umd/ffmpeg-core.wasm

## How to add the files:

1. Download both files from the URLs above
2. Place them in this directory (`public/ffmpeg-core/`)
3. The application will automatically use these local files instead of fetching from unpkg.com

This resolves CORS policy issues when running the application locally.
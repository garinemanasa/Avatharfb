/*
  # Create feedback media storage bucket

  1. Storage Setup
    - Create 'feedback-media' bucket for storing audio/video files
    - Configure bucket for public access (anonymous uploads)

  2. Security Policies
    - Allow anonymous users to upload files (INSERT)
    - Allow anonymous users to read files (SELECT)
    - Restrict file types to audio/video formats
    - Set reasonable file size limits
*/

-- Create the feedback-media bucket
INSERT INTO storage.buckets (id, name, public) 
VALUES ('feedback-media', 'feedback-media', true)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy to allow anonymous users to upload files to feedback-media bucket
CREATE POLICY "Allow anonymous uploads to feedback-media"
ON storage.objects
FOR INSERT
TO anon
WITH CHECK (
  bucket_id = 'feedback-media' AND
  (storage.foldername(name))[1] = '' AND -- files in root of bucket
  (
    (name ~ '\.(mp4|webm|avi|mov|m4v)$') OR -- video formats
    (name ~ '\.(webm|mp3|wav|m4a|ogg)$')    -- audio formats
  )
);

-- Policy to allow anonymous users to read files from feedback-media bucket
CREATE POLICY "Allow anonymous downloads from feedback-media"
ON storage.objects
FOR SELECT
TO anon
USING (bucket_id = 'feedback-media');

-- Policy to allow authenticated users full access
CREATE POLICY "Allow authenticated users full access to feedback-media"
ON storage.objects
FOR ALL
TO authenticated
USING (bucket_id = 'feedback-media')
WITH CHECK (bucket_id = 'feedback-media');
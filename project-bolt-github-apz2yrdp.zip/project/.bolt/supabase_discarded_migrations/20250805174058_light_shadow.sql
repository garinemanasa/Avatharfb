/*
  # Create feedback system tables

  1. New Tables
    - `feedback_sessions`
      - `id` (uuid, primary key)
      - `consent` (boolean) - user consent for sharing
      - `selected_mode` (text) - video, audio, or text
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `completed` (boolean) - session completion status
      - `drive_file_id` (text) - Google Drive file ID for final video
      
    - `text_feedback`
      - `id` (uuid, primary key)
      - `session_id` (uuid, foreign key)
      - `question_number` (integer)
      - `text_response` (text)
      - `star_rating` (integer)
      - `created_at` (timestamp)
      
    - `audio_feedback`
      - `id` (uuid, primary key)
      - `session_id` (uuid, foreign key)
      - `question_number` (integer)
      - `storage_url` (text) - Supabase storage URL
      - `file_size` (bigint) - file size in bytes
      - `duration` (numeric) - duration in seconds
      - `created_at` (timestamp)
      
    - `video_feedback`
      - `id` (uuid, primary key)
      - `session_id` (uuid, foreign key)
      - `question_number` (integer)
      - `storage_url` (text) - Supabase storage URL
      - `file_size` (bigint) - file size in bytes
      - `duration` (numeric) - duration in seconds
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create feedback_sessions table
CREATE TABLE IF NOT EXISTS feedback_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  consent boolean NOT NULL DEFAULT false,
  selected_mode text NOT NULL CHECK (selected_mode IN ('video', 'audio', 'text')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed boolean DEFAULT false,
  drive_file_id text
);

-- Create text_feedback table
CREATE TABLE IF NOT EXISTS text_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES feedback_sessions(id) ON DELETE CASCADE,
  question_number integer NOT NULL CHECK (question_number >= 1 AND question_number <= 5),
  text_response text NOT NULL,
  star_rating integer NOT NULL CHECK (star_rating >= 1 AND star_rating <= 5),
  created_at timestamptz DEFAULT now()
);

-- Create audio_feedback table
CREATE TABLE IF NOT EXISTS audio_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES feedback_sessions(id) ON DELETE CASCADE,
  question_number integer NOT NULL CHECK (question_number >= 1 AND question_number <= 5),
  storage_url text NOT NULL,
  file_size bigint NOT NULL,
  duration numeric,
  created_at timestamptz DEFAULT now()
);

-- Create video_feedback table
CREATE TABLE IF NOT EXISTS video_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES feedback_sessions(id) ON DELETE CASCADE,
  question_number integer NOT NULL CHECK (question_number >= 1 AND question_number <= 5),
  storage_url text NOT NULL,
  file_size bigint NOT NULL,
  duration numeric,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE feedback_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE text_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE audio_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_feedback ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (since this is a customer feedback system)
-- Sessions can be created and read by anyone
CREATE POLICY "Allow public session creation"
  ON feedback_sessions
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public session read"
  ON feedback_sessions
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public session update"
  ON feedback_sessions
  FOR UPDATE
  TO anon
  USING (true);

-- Text feedback policies
CREATE POLICY "Allow public text feedback creation"
  ON text_feedback
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public text feedback read"
  ON text_feedback
  FOR SELECT
  TO anon
  USING (true);

-- Audio feedback policies
CREATE POLICY "Allow public audio feedback creation"
  ON audio_feedback
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public audio feedback read"
  ON audio_feedback
  FOR SELECT
  TO anon
  USING (true);

-- Video feedback policies
CREATE POLICY "Allow public video feedback creation"
  ON video_feedback
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public video feedback read"
  ON video_feedback
  FOR SELECT
  TO anon
  USING (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_feedback_sessions_created_at ON feedback_sessions(created_at);
CREATE INDEX IF NOT EXISTS idx_text_feedback_session_id ON text_feedback(session_id);
CREATE INDEX IF NOT EXISTS idx_audio_feedback_session_id ON audio_feedback(session_id);
CREATE INDEX IF NOT EXISTS idx_video_feedback_session_id ON video_feedback(session_id);
CREATE INDEX IF NOT EXISTS idx_feedback_question_number ON text_feedback(question_number);
CREATE INDEX IF NOT EXISTS idx_audio_question_number ON audio_feedback(question_number);
CREATE INDEX IF NOT EXISTS idx_video_question_number ON video_feedback(question_number);
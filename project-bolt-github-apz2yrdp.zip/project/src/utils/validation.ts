import sanitizeHtml from 'sanitize-html';

export const BANNED_WORDS = [
  'inappropriate',
  'offensive',
  'spam',
];

export const validateTextInput = (text: string): { isValid: boolean; error?: string } => {
  if (!text || text.trim().length === 0) {
    return { isValid: false, error: 'Please provide a response' };
  }

  if (text.length > 500) {
    return { isValid: false, error: 'Response must be 500 characters or less' };
  }

  const sanitized = sanitizeHtml(text, {
    allowedTags: [],
    allowedAttributes: {},
  });

  const lowerText = sanitized.toLowerCase();
  const containsBannedWord = BANNED_WORDS.some(word => lowerText.includes(word));

  if (containsBannedWord) {
    return {
      isValid: false,
      error: 'We cannot accept this kind of response. Please try again.',
    };
  }

  return { isValid: true };
};

export const validateMediaFile = (
  file: File,
  type: 'video' | 'audio'
): { isValid: boolean; error?: string } => {
  const maxSize = type === 'video' ? 50 * 1024 * 1024 : 10 * 1024 * 1024; // 50MB or 10MB
  const allowedTypes =
    type === 'video'
      ? ['video/mp4', 'video/mov', 'video/quicktime', 'video/webm', 'video/ogg']
      : ['audio/mp3', 'audio/wav', 'audio/mpeg'];

  if (file.size > maxSize) {
    return {
      isValid: false,
      error: `File size must be less than ${type === 'video' ? '50MB' : '10MB'}`,
    };
  }

  if (!allowedTypes.includes(file.type)) {
    return {
      isValid: false,
      error: `Invalid file type. Please use: ${allowedTypes.join(', ')}`,
    };
  }

  return { isValid: true };
};

export const checkDurationLimit = async (
  blob: Blob,
  recordingDuration?: number,
  type: 'video' | 'audio' = 'video'
): Promise<{ isValid: boolean; error?: string }> => {
  return new Promise((resolve, reject) => {
    try {
      console.log(`[Duration Check] Starting duration check for ${type}, recordingDuration provided:`, recordingDuration, 'blob size:', blob.size);
      
      // Explicit check for zero duration
      if (recordingDuration === 0) {
        console.log(`[Duration Check] Recording duration is 0 - too short`);
        resolve({
          isValid: false,
          error: 'Recording is too short. Please record for at least 1 second.',
        });
        return;
      }
      
      // If we have a valid recording duration from the timer, use it directly
      if (recordingDuration && recordingDuration > 0) {
        console.log(`[Duration Check] Using provided recording duration:`, recordingDuration, 'seconds');
        if (recordingDuration > 180) {
          console.log(`[Duration Check] Provided duration too long:`, recordingDuration);
          resolve({
            isValid: false,
            error: 'Recording must be 3 minutes or less',
          });
        } else {
          console.log(`[Duration Check] Provided duration valid:`, recordingDuration);
          resolve({ isValid: true });
        }
        return;
      }
      
      console.log(`[Duration Check] No valid recording duration provided, falling back to blob analysis`);
      const url = URL.createObjectURL(blob);
      const media = type === 'video' 
        ? document.createElement('video') as HTMLVideoElement
        : document.createElement('audio') as HTMLAudioElement;

      media.preload = 'metadata';
      if (type === 'video') {
        (media as HTMLVideoElement).muted = true;
      }
      media.src = url;

      let callbackFired = false;

      media.onloadedmetadata = () => {
        console.log(`[Duration Check] onloadedmetadata fired, duration:`, media.duration);
        callbackFired = true;

        if (media.duration === Infinity || isNaN(media.duration) || !isFinite(media.duration) || media.duration <= 0) {
          console.log(`[Duration Check] Duration is Infinity, using seek trick`);
          // Use a seek trick to calculate duration
          media.currentTime = 1e101;
          media.ontimeupdate = () => {
            media.ontimeupdate = null;
            const duration = media.duration;
            console.log(`[Duration Check] After seek trick, duration:`, duration);
            URL.revokeObjectURL(url);

            if (isNaN(duration) || !isFinite(duration) || duration <= 0) {
              console.log(`[Duration Check] Invalid duration after seek trick:`, duration);
              resolve({
                isValid: false,
                error: 'Invalid media duration detected after seek trick.',
              });
              return;
            }

            if (duration < 0.5) {
              console.log(`[Duration Check] Duration too short:`, duration);
              resolve({
                isValid: false,
                error: 'Recording is too short. Please record for at least 0.5 seconds.',
              });
              return;
            }

            if (duration > 180) {
              console.log(`[Duration Check] Duration too long:`, duration);
              resolve({
                isValid: false,
                error: 'Recording must be 3 minutes or less',
              });
            } else {
              console.log(`[Duration Check] Duration valid:`, duration);
              resolve({ isValid: true });
            }
          };
        } else {
          const duration = media.duration;
          console.log(`[Duration Check] Direct duration:`, duration);
          URL.revokeObjectURL(url);

          if (isNaN(duration) || !isFinite(duration) || duration <= 0) {
            console.log(`[Duration Check] Invalid direct duration:`, duration);
            resolve({
              isValid: false,
              error: 'Invalid media duration detected.',
            });
            return;
          }

          if (duration < 0.5) {
            console.log(`[Duration Check] Duration too short:`, duration);
            resolve({
              isValid: false,
              error: 'Recording is too short. Please record for at least 0.5 seconds.',
            });
            return;
          }

          if (duration > 180) {
            console.log(`[Duration Check] Direct duration too long:`, duration);
            resolve({
              isValid: false,
              error: 'Recording must be 3 minutes or less',
            });
          } else {
            console.log(`[Duration Check] Direct duration valid:`, duration);
            resolve({ isValid: true });
          }
        }
      };

      media.onerror = () => {
        console.error(`[Duration Check] Media error occurred - failed to load media metadata`);
        callbackFired = true;
        URL.revokeObjectURL(url);
        resolve({ isValid: false, error: 'Failed to load media metadata for duration check.' });
      };

      setTimeout(() => {
        if (!callbackFired) {
          console.error(`[Duration Check] Timeout reached after 30 seconds, callbackFired:`, callbackFired);
          URL.revokeObjectURL(url);
          resolve({ isValid: false, error: 'Timeout validating recording duration. Please try a shorter recording.' });
        }
      }, 30000);

      console.log(`[Duration Check] Starting media load`);
      media.load();
    } catch (err) {
      console.error(`[Duration Check] Exception:`, err);
      reject(
        new Error(
          'Failed to process video file: ' +
            (err instanceof Error ? err.message : 'Unknown error')
        )
      );
    }
  });
};

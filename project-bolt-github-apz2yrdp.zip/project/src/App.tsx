import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Truck } from 'lucide-react';

// Components
import { VideoPlayer } from './components/VideoPlayer';
import { ModeSelector } from './components/ModeSelector';
import { ConsentForm } from './components/ConsentForm';
import { FeedbackCapture } from './components/FeedbackCapture';
import { ProgressIndicator } from './components/ProgressIndicator';
import { AccessibilityControls } from './components/AccessibilityControls';
import { SessionUploader } from './components/SessionUploader';

// Hooks
import { useVideoProcessing } from './hooks/useVideoProcessing';
import { useGoogleDrive } from './hooks/useGoogleDrive';
import { useSupabaseFeedback } from './hooks/useSupabaseFeedback';

// Utils
import { saveSession, loadSession, clearSession } from './utils/storage';

// Types
import { AppState, FeedbackResponse } from './types';

// Config
import { VIDEO_CONFIG } from './config/videos';

const STEP_LABELS = ['Welcome', 'Mode', 'Consent', 'Feedback', 'Complete'];

function App() {
  // Core state
  const [state, setState] = useState<AppState>({
    currentStep: 'welcome',
    currentQuestion: 1,
    selectedMode: null,
    consent: null,
    responses: [],
    isProcessing: false,
    error: null,
    highContrast: false
  });

  // Accessibility state
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);

  // Hooks
  const { stitchVideos, isProcessing: isVideoProcessing, progress: videoProgress } = useVideoProcessing();
  const { uploadToGoogleDrive, isUploading, uploadProgress } = useGoogleDrive();
  const { 
    createFeedbackSession, 
    saveFeedbackResponse, 
    fetchFeedbackResponsesForSession,
    updateSessionCompletion,
    isUploading: isSupabaseUploading,
    uploadProgress: supabaseUploadProgress,
    error: supabaseError
  } = useSupabaseFeedback();

  // Load saved session on mount
  useEffect(() => {
    const savedSession = loadSession();
    if (savedSession) {
      setState(prev => ({ ...prev, ...savedSession }));
    }
    
    // Debug: Log video configuration
    console.log('App started - Video config:', VIDEO_CONFIG);
  }, []);

  // Save session whenever state changes
  useEffect(() => {
    saveSession(state);
  }, [state]);

  // Apply high contrast styles
  useEffect(() => {
    if (state.highContrast) {
      document.body.classList.add('high-contrast');
    } else {
      document.body.classList.remove('high-contrast');
    }
  }, [state.highContrast]);

  // Create Supabase session when consent and mode are determined
  useEffect(() => {
    const createSession = async () => {
      if (state.consent !== null && state.selectedMode && !currentSessionId) {
        console.log('Creating Supabase session with:', { consent: state.consent, mode: state.selectedMode });
        const sessionId = await createFeedbackSession(state.consent, state.selectedMode);
        if (sessionId) {
          setCurrentSessionId(sessionId);
          console.log('Created Supabase session:', sessionId);
        } else {
          console.error('Failed to create Supabase session');
          updateState({ 
            error: 'Failed to initialize feedback session. Please refresh and try again.',
          });
        }
      }
    };

    createSession();
  }, [state.consent, state.selectedMode, currentSessionId, createFeedbackSession]);

  const updateState = useCallback((updates: Partial<AppState>) => {
    setState(prev => ({ ...prev, ...updates }));
  }, []);

  const handleWelcomeComplete = () => {
    updateState({ currentStep: 'mode-selection' });
  };

  const handleModeSelect = (mode: 'video' | 'audio' | 'text') => {
    updateState({ 
      selectedMode: mode, 
      currentStep: 'consent' 
    });
  };

  const handleConsentChange = (consent: boolean) => {
    updateState({ 
      consent, 
      currentStep: 'feedback' 
    });
  };

  const handleResponse = async (response: FeedbackResponse) => {
    // Save individual response to Supabase if session exists
    if (currentSessionId) {
      const saved = await saveFeedbackResponse(currentSessionId, response);
      if (!saved) {
        updateState({ 
          error: 'Failed to save your response. Please try again.',
        });
        return;
      }
    }

    const newResponses = [...state.responses, response];
    updateState({ responses: newResponses });

    if (state.currentQuestion < 5) {
      // Move to next question
      updateState({ currentQuestion: state.currentQuestion + 1 });
    } else {
      // All questions completed, show closing video
      updateState({ currentStep: 'closing' });
    }
  };

  const handleClosingComplete = async () => {
    updateState({ 
      currentStep: 'processing',
      isProcessing: true 
    });

    try {
      // Fetch all responses for this session from Supabase
      let responsesToStitch = state.responses;
      if (currentSessionId) {
        console.log('Fetching responses from Supabase for session:', currentSessionId);
        const fetchedResponses = await fetchFeedbackResponsesForSession(currentSessionId);
        if (fetchedResponses.length > 0) {
          responsesToStitch = fetchedResponses;
          console.log('Using fetched responses from Supabase:', fetchedResponses.length, 'responses');
        } else {
          console.log('No responses found in Supabase, using in-memory responses');
        }
      }
      
      // Stitch videos together
      const aiVideoUrls = [
        VIDEO_CONFIG.welcome,
        ...VIDEO_CONFIG.questions,
        VIDEO_CONFIG.closing
      ];

      const stitchedVideo = await stitchVideos(responsesToStitch, aiVideoUrls);

      // Upload to Google Drive
      const filename = `feedback_${Date.now()}.mp4`;
      const uploadResult = await uploadToGoogleDrive(
        stitchedVideo,
        filename,
        state.consent || false
      );

      if (uploadResult.success) {
        // Update Supabase session with completion status and Drive file ID
        if (currentSessionId) {
          await updateSessionCompletion(currentSessionId, uploadResult.fileId);
        }
        
        updateState({ 
          currentStep: 'complete',
          isProcessing: false 
        });
        
        // Clear session after successful completion
        setTimeout(() => {
          clearSession();
          setCurrentSessionId(null);
        }, 5000);
      } else {
        throw new Error(uploadResult.error || 'Upload failed');
      }
    } catch (error) {
      updateState({ 
        error: error instanceof Error ? error.message : 'Processing failed',
        isProcessing: false 
      });
    }
  };

  const handleRestart = () => {
    clearSession();
    setCurrentSessionId(null);
    setState({
      currentStep: 'welcome',
      currentQuestion: 1,
      selectedMode: null,
      consent: null,
      responses: [],
      isProcessing: false,
      error: null,
      highContrast: state.highContrast // Preserve accessibility setting
    });
  };

  const getCurrentStepNumber = (): number => {
    switch (state.currentStep) {
      case 'welcome': return 1;
      case 'mode-selection': return 2;
      case 'consent': return 3;
      case 'feedback': return 4;
      case 'closing':
      case 'processing':
      case 'complete': return 5;
      default: return 1;
    }
  };

  const getMainContent = () => {
    switch (state.currentStep) {
      case 'welcome':
        return (
          <VideoPlayer
            src={VIDEO_CONFIG.welcome}
            onEnded={handleWelcomeComplete}
            autoPlay={true}
            aria-label="Welcome message from food truck"
          />
        );

      case 'mode-selection':
        return (
          <ModeSelector
            onModeSelect={handleModeSelect}
            highContrast={state.highContrast}
          />
        );

      case 'consent':
        return (
          <ConsentForm
            onConsentChange={handleConsentChange}
            highContrast={state.highContrast}
          />
        );

      case 'feedback':
        return (
          <div className="space-y-6">
            <VideoPlayer
              src={VIDEO_CONFIG.questions[state.currentQuestion - 1]}
              onEnded={() => {}} // Video pauses for response
              autoPlay={true}
              aria-label={`Feedback question ${state.currentQuestion}`}
            />
            
            {state.selectedMode && (
              <FeedbackCapture
                mode={state.selectedMode}
                questionNumber={state.currentQuestion}
                onResponse={handleResponse}
                highContrast={state.highContrast}
              />
            )}
          </div>
        );

      case 'closing':
        return (
          <VideoPlayer
            src={VIDEO_CONFIG.closing}
            onEnded={handleClosingComplete}
            autoPlay={true}
            aria-label="Closing message from food truck"
          />
        );

      case 'processing':
        return (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-6"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${
                state.highContrast ? 'bg-blue-700' : 'bg-blue-100'
              }`}
            >
              <Truck size={40} className={state.highContrast ? 'text-white' : 'text-blue-600'} />
            </motion.div>
            
            <div>
              <h2 className={`text-2xl font-bold mb-2 ${state.highContrast ? 'text-white' : 'text-gray-800'}`}>
                Processing Your Feedback
              </h2>
              <p className={`text-lg ${state.highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                Creating your personalized video response...
              </p>
            </div>

            <div className="space-y-2">
              <div className={`w-full max-w-md mx-auto h-2 rounded-full overflow-hidden ${
                state.highContrast ? 'bg-gray-700' : 'bg-gray-200'
              }`}>
                <motion.div
                  className={`h-full rounded-full ${
                    state.highContrast ? 'bg-blue-500' : 'bg-blue-600'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.max(videoProgress, uploadProgress, supabaseUploadProgress)}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              <p className={`text-sm ${state.highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
                {Math.max(videoProgress, uploadProgress, supabaseUploadProgress)}% complete
              </p>
            </div>
          </motion.div>
        );

      case 'complete':
        return (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-6"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${
                state.highContrast ? 'bg-green-700' : 'bg-green-100'
              }`}
            >
              <Truck size={40} className={state.highContrast ? 'text-white' : 'text-green-600'} />
            </motion.div>
            
            <div>
              <h2 className={`text-3xl font-bold mb-4 ${state.highContrast ? 'text-white' : 'text-gray-800'}`}>
                Thank You! 🎉
              </h2>
              <p className={`text-lg mb-6 ${state.highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
                Your feedback has been successfully recorded and processed!
              </p>
              
              {(state.error || supabaseError) && (
                <p className="text-sm mb-4">{state.error || supabaseError}</p>
              )}
              
              {(state.error || supabaseError) && (
                <p className="text-sm mb-4">{state.error || supabaseError}</p>
              )}
              
              {state.consent && (
                <p className={`text-sm mb-6 ${state.highContrast ? 'text-gray-400' : 'text-gray-500'}`}>
                  Your response may be featured on our social media platforms to help others discover our food truck.
                </p>
              )}
            </div>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleRestart}
              className={`px-8 py-3 rounded-lg font-medium transition-colors focus:outline-none focus:ring-4 focus:ring-opacity-50 ${
                state.highContrast
                  ? 'bg-blue-700 text-white hover:bg-blue-600 focus:ring-blue-400'
                  : 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500'
              }`}
            >
              Leave Another Review
            </motion.button>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`min-h-screen transition-all duration-300 ${
      state.highContrast 
        ? 'bg-black text-white' 
        : 'bg-gradient-to-br from-gray-50 to-blue-50'
    }`}>
      {/* Accessibility Controls */}
      <AccessibilityControls
        highContrast={state.highContrast}
        onToggleHighContrast={() => updateState({ highContrast: !state.highContrast })}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
      />

      {/* Header */}
      <header className="pt-8 pb-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className={`inline-flex items-center space-x-3 mb-4 ${
            state.highContrast ? 'text-white' : 'text-gray-800'
          }`}>
            <Truck size={48} className={state.highContrast ? 'text-blue-400' : 'text-blue-600'} />
            <h1 className="text-3xl md:text-4xl font-bold">FoodTruck Feedback</h1>
          </div>
          <p className={`text-base md:text-lg ${state.highContrast ? 'text-gray-300' : 'text-gray-600'}`}>
            Share your experience with us
          </p>
        </motion.div>
      </header>

      {/* Progress Indicator */}
      {state.currentStep !== 'complete' && (
        <ProgressIndicator
          currentStep={getCurrentStepNumber()}
          totalSteps={5}
          stepLabels={STEP_LABELS}
          highContrast={state.highContrast}
        />
      )}

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={state.currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {getMainContent()}
          </motion.div>
        </AnimatePresence>

        {/* Error Display */}
        <AnimatePresence>
          {state.error && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`mt-8 p-4 rounded-lg text-center ${
                state.highContrast ? 'bg-red-900 text-red-300' : 'bg-red-50 text-red-800'
              }`}
              role="alert"
            >
              <p className="font-medium mb-2">Something went wrong</p>
              <p className="text-sm mb-4">{state.error}</p>
              <button
                onClick={handleRestart}
                className={`px-4 py-2 rounded-lg font-medium transition-colors focus:outline-none focus:ring-4 focus:ring-opacity-50 ${
                  state.highContrast
                    ? 'bg-blue-700 text-white hover:bg-blue-600 focus:ring-blue-400'
                    : 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500'
                }`}
              >
                Start Over
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className={`py-8 text-center text-sm ${
        state.highContrast ? 'text-gray-400' : 'text-gray-500'
      }`}>
        <p>© 2025 FoodTruck Feedback Experience</p>
        <p className="mt-1">
          Your privacy is protected. All responses are handled securely and in compliance with GDPR/CCPA regulations.
        </p>
      </footer>
    </div>
  );
}

export default App;
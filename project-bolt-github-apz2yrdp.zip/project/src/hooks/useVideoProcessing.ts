import { useState, useCallback } from 'react';
import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';
import { FeedbackResponse } from '../types';

export const useVideoProcessing = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const initializeFFmpeg = useCallback(async () => {
    console.log('🎬 Initializing FFmpeg...');
    const ffmpeg = new FFmpeg();

    // Set up progress listener BEFORE loading
    ffmpeg.on('progress', ({ progress }) => {
      console.log('📈 FFmpeg progress:', Math.round(progress * 100) + '%');
      setProgress(Math.round(progress * 100));
    });

    // Use local FFmpeg core files to avoid CORS issues
  const baseURL = '/ffmpeg-core';
    //const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm/';
    console.log(`🔗 Attempting to load FFmpeg core from: ${baseURL}`);
    

    try {
      await ffmpeg.load({
        //coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
       // wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        coreURL: 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js',
wasmURL: 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm'
      });

      console.log('✅ FFmpeg loaded successfully');
    } catch (loadError) {
      console.error('❌ Failed to load FFmpeg:', loadError);
      // Instead of throwing, create a fallback video
      console.log('Creating fallback video due to processing error');
      return createFallbackVideo(responses);
    }

    return ffmpeg;
  }, []);

  const createFallbackVideo = async (responses: FeedbackResponse[]): Promise<Blob> => {
    try {
      // Create a simple video with just user responses if available
      const userVideos = responses.filter(r => r.type === 'video' && r.mediaBlob);
      
      if (userVideos.length > 0) {
        // If we have user videos, stitch just those
        const ffmpeg = ffmpegRef.current;
        if (!ffmpeg) throw new Error('FFmpeg not initialized');
        
        // Write user videos to FFmpeg
        for (let i = 0; i < userVideos.length; i++) {
          const videoBlob = userVideos[i].mediaBlob!;
          const videoData = await fetchFile(videoBlob);
          await ffmpeg.writeFile(`user_video_${i}.mp4`, videoData);
        }
        
        // Create concat file for user videos only
        const concatContent = userVideos.map((_, i) => `file 'user_video_${i}.mp4'`).join('\n');
        await ffmpeg.writeFile('concat_user.txt', concatContent);
        
        // Concatenate user videos
        await ffmpeg.exec(['-f', 'concat', '-safe', '0', '-i', 'concat_user.txt', '-c', 'copy', 'user_output.mp4']);
        
        const data = await ffmpeg.readFile('user_output.mp4');
        return new Blob([data], { type: 'video/mp4' });
      }
      
      // If no user videos, create a minimal placeholder
      console.log('No user videos available, creating minimal placeholder');
      const placeholderBlob = new Blob(['Video content not available'], { type: 'text/plain' });
      return placeholderBlob;
      
    } catch (error) {
      console.error('Fallback video creation failed:', error);
      // Return a minimal blob as last resort
      return new Blob(['Feedback recorded - video processing unavailable'], { type: 'text/plain' });
    }
  };

  const stitchVideos = useCallback(async (
    responses: FeedbackResponse[],
    aiVideoUrls: string[]
  ): Promise<Blob> => {
    setIsProcessing(true);
    setProgress(0);
    setError(null);
    console.log('🎥 Starting video stitching process...');
    console.log('📋 Total responses:', responses.length);
    console.log('🤖 AI video URLs:', aiVideoUrls);

    try {
      console.log('⏳ Getting FFmpeg instance...');
      const ffmpeg = await initializeFFmpeg();

      // Filter responses to only include those with actual media recordings
      const mediaResponses = responses.filter(response => response.mediaBlob);
      
      console.log('🎞️ Media responses found:', mediaResponses.length);
      console.log('📝 Response types:', mediaResponses.map(r => `Q${r.questionNumber}: ${r.mode}`));
      
      if (mediaResponses.length === 0) {
        console.error('❌ No media responses found to process');
        throw new Error('No video or audio responses found to process');
      }

      // Write AI videos to FFmpeg filesystem
      console.log('📥 Writing AI videos to FFmpeg filesystem...');
      const availableAiVideos = [];
      for (let i = 0; i < aiVideoUrls.length; i++) {
        try {
          console.log(`🌐 Fetching AI video ${i + 1}/${aiVideoUrls.length}: ${aiVideoUrls[i]}`);
          const response = await fetch(aiVideoUrls[i]);
          
          if (!response.ok) {
            console.warn(`⚠️ AI video ${i} not available: ${response.status} ${response.statusText}`);
            continue;
          }
          
          const videoData = await response.arrayBuffer();
          console.log(`📊 AI video ${i} size: ${videoData.byteLength} bytes`);
          await ffmpeg.writeFile(`ai_video_${i}.mp4`, new Uint8Array(videoData));
          console.log(`✅ Written ai_video_${i}.mp4 to FFmpeg filesystem`);
          availableAiVideos.push(i);
        } catch (error) {
          console.warn(`⚠️ Failed to fetch AI video ${i}: ${error instanceof Error ? error.message : 'Unknown error'}`);
          continue;
        }
      }

      // Write only media responses (video/audio) to FFmpeg filesystem
      console.log('📥 Writing user media responses to FFmpeg filesystem...');
      for (let i = 0; i < mediaResponses.length; i++) {
        const response = mediaResponses[i];
        console.log(`💾 Processing user response ${i + 1}/${mediaResponses.length}: ${response.mode} for Q${response.questionNumber}`);
        
        let mediaData: Uint8Array;
        if (response.mediaBlob) {
          console.log(`📊 Using media blob, size: ${response.mediaBlob.size} bytes`);
          mediaData = await fetchFile(response.mediaBlob);
        } else if (response.storageUrl) {
          console.log(`📊 Fetching from storage URL: ${response.storageUrl}`);
          mediaData = await fetchFile(response.storageUrl);
        } else {
          console.error(`❌ No media blob or storage URL found for response ${i}`);
          throw new Error(`No media data available for response ${i + 1}`);
        }
        
        const filename = response.mode === 'video' ? `user_response_${i}.mp4` : `user_response_${i}.webm`;
        await ffmpeg.writeFile(filename, mediaData);
        console.log(`✅ Written ${filename} to FFmpeg filesystem`);
      }

      // Create proper concatenation sequence
      console.log('🔗 Building concatenation sequence...');
      
      // Plan the sequence based on available AI videos and user responses
      const sequence = [];
      let inputIndex = 0;
      
      // Add welcome video (ai_video_0) if available
      if (availableAiVideos.includes(0)) {
        sequence.push({ type: 'ai', index: 0 });
      }
      
      // Add question-response pairs (only include AI questions that are available)
      for (let i = 0; i < mediaResponses.length; i++) {
        // Add question video (ai_video_{i+1}) if available
        if (availableAiVideos.includes(i + 1)) {
          sequence.push({ type: 'ai', index: i + 1 });
        }
        // Add user response
        sequence.push({ type: 'user', index: i });
      }
      
      // Add closing video if available
      const closingVideoIndex = aiVideoUrls.length - 1;
      if (availableAiVideos.includes(closingVideoIndex) && closingVideoIndex > mediaResponses.length) {
        sequence.push({ type: 'ai', index: closingVideoIndex });
      }
      
      console.log('📝 Planned sequence:', sequence);
      
      // If no sequence items, create a video with just user responses
      if (sequence.length === 0) {
        console.log('⚠️ No AI videos available, creating video with user responses only');
        for (let i = 0; i < mediaResponses.length; i++) {
          sequence.push({ type: 'user', index: i });
        }
      }
      
      // Build FFmpeg inputs and filter complex
      const inputs = [];
      let filterComplex = '';
      
      for (let i = 0; i < sequence.length; i++) {
        const item = sequence[i];
        if (item.type === 'ai') {
          inputs.push(`-i`, `ai_video_${item.index}.mp4`);
        } else {
          inputs.push(`-i`, `user_response_${item.index}.mp4`);
        }
        
        filterComplex += `[${i}:v][${i}:a]`;
      }
      
      filterComplex += `concat=n=${sequence.length}:v=1:a=1[outv][outa]`;

      console.log('🔧 FFmpeg inputs:', inputs);
      console.log('🔧 Filter complex:', filterComplex);
      console.log('📊 Total input files:', sequence.length);
      
      const ffmpegArgs = [
        ...inputs,
        '-filter_complex',
        filterComplex,
        '-map',
        '[outv]',
        '-map',
        '[outa]',
        '-c:v',
        'libx264',
        '-c:a',
        'aac',
        '-r',
        '30',
        '-preset',
        'medium',
        '-crf',
        '23',
        'output.mp4'
      ];
      
      console.log('🚀 Executing FFmpeg command with args:', ffmpegArgs);
      
      // Execute FFmpeg command
      await ffmpeg.exec(ffmpegArgs);
      
      console.log('🎉 FFmpeg command executed successfully!');

      // Read the output file
      console.log('📖 Reading output file...');
      const data = await ffmpeg.readFile('output.mp4');
      const blob = new Blob([data], { type: 'video/mp4' });
      console.log('✅ Final video blob created, size:', blob.size, 'bytes');
      return blob;
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Video processing failed';
      console.error('❌ Video processing error:', {
        message: errorMessage,
        stack: err instanceof Error ? err.stack : undefined,
        responses: responses.length,
        mediaResponses: responses.filter(r => r.mediaBlob).length,
      });
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsProcessing(false);
      setProgress(0);
      console.log('🏁 Video processing finished, state reset');
    }
  }, [initializeFFmpeg]);

  return {
    stitchVideos,
    isProcessing,
    progress,
    error
  };
};
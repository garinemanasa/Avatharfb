import { useState, useCallback } from 'react';
import { useEffect } from 'react';
import { GOOGLE_DRIVE_CONFIG } from '../config/videos';
import { supabase } from '../utils/supabase';
import { FeedbackResponse } from '../types';

interface UploadResult {
  fileId: string;
  success: boolean;
  error?: string;
}

interface SessionUploadResult {
  sessionId: string;
  success: boolean;
  folderId?: string;
  uploadedFiles: string[];
  errors: string[];
}
export const useGoogleDrive = () => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [gapiReady, setGapiReady] = useState(false);

  useEffect(() => {
    const initializeGapi = async () => {
      if (window.gapi) {
        setGapiReady(true);
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://apis.google.com/js/api.js';
      script.onload = () => {
        window.gapi.load('auth2:client', {
          callback: () => setGapiReady(true),
          onerror: () => console.error('Failed to load gapi')
        });
      };
      script.onerror = () => console.error('Failed to load gapi script');
      document.head.appendChild(script);
    };

    initializeGapi();
  }, []);

  const authenticate = useCallback(async () => {
    if (!gapiReady) {
      throw new Error('Google API not ready');
    }
    
    await window.gapi.client.init({
      apiKey: GOOGLE_DRIVE_CONFIG.apiKey,
      clientId: GOOGLE_DRIVE_CONFIG.clientId,
      discoveryDocs: ['https://www.googleapis.com/discovery/v1/apis/drive/v3/rest'],
      scope: 'https://www.googleapis.com/auth/drive.file'
    });

    const authInstance = window.gapi.auth2.getAuthInstance();
    if (!authInstance.isSignedIn.get()) {
      await authInstance.signIn();
    }
  }, [gapiReady]);

  const uploadToGoogleDrive = useCallback(async (
    videoBlob: Blob,
    filename: string,
    hasConsent: boolean
  ): Promise<UploadResult> => {
    if (!gapiReady) {
      return { fileId: '', success: false, error: 'Google API not ready' };
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      await authenticate();

      const folderId = hasConsent 
        ? GOOGLE_DRIVE_CONFIG.socialFolderId 
        : GOOGLE_DRIVE_CONFIG.privateFolderId;

      const metadata = {
        name: filename,
        parents: [folderId]
      };

      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', videoBlob);

      const xhr = new XMLHttpRequest();
      
      return new Promise((resolve, reject) => {
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            setUploadProgress(Math.round((e.loaded / e.total) * 100));
          }
        };

        xhr.onload = () => {
          setIsUploading(false);
          if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            resolve({ fileId: response.id, success: true });
            console.log(response.id, 'Success in uploading')
          } else {
            reject(new Error(`Upload failed: ${xhr.statusText}`));
          }
        };
        

        xhr.onerror = () => {
          setIsUploading(false);
          reject(new Error('Upload failed'));
        };

        xhr.open('POST', 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart');
        xhr.setRequestHeader('Authorization', `Bearer ${window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse().access_token}`);
        xhr.send(form);
      });

    } catch (error) {
      setIsUploading(false);
      const errorMessage = error instanceof Error ? error.message : 'Upload failed';
      return { fileId: '', success: false, error: errorMessage };
    }
  }, [authenticate]);

  const createFolder = useCallback(async (folderName: string, parentFolderId: string): Promise<string | null> => {
    if (!gapiReady) {
      return null;
    }

    try {
      await authenticate();

      const metadata = {
        name: folderName,
        parents: [parentFolderId],
        mimeType: 'application/vnd.google-apps.folder'
      };

      const response = await window.gapi.client.request({
        path: 'https://www.googleapis.com/drive/v3/files',
        method: 'POST',
        body: JSON.stringify(metadata),
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 200) {
        const result = JSON.parse(response.body);
        return result.id;
      } else {
        console.error('Failed to create folder:', response.statusText);
        return null;
      }
    } catch (error) {
      console.error('Error creating folder:', error);
      return null;
    }
  }, [authenticate, gapiReady]);

  const uploadSessionResponsesToDrive = useCallback(async (
    sessionId: string,
    hasConsent: boolean
  ): Promise<SessionUploadResult> => {
    if (!gapiReady) {
      return {
        sessionId,
        success: false,
        uploadedFiles: [],
        errors: ['Google API not ready']
      };
    }

    setIsUploading(true);
    setUploadProgress(0);

    const result: SessionUploadResult = {
      sessionId,
      success: false,
      uploadedFiles: [],
      errors: []
    };

    try {
      await authenticate();

      // Fetch all media responses for this session
      const [audioData, videoData] = await Promise.all([
        supabase
          .from('audio_feedback')
          .select('*')
          .eq('session_id', sessionId)
          .order('question_number'),
        supabase
          .from('video_feedback')
          .select('*')
          .eq('session_id', sessionId)
          .order('question_number')
      ]);

      const allResponses = [
        ...(audioData.data || []).map(item => ({
          ...item,
          type: 'audio' as const
        })),
        ...(videoData.data || []).map(item => ({
          ...item,
          type: 'video' as const
        }))
      ].sort((a, b) => a.question_number - b.question_number);

      if (allResponses.length === 0) {
        result.errors.push('No media responses found for this session');
        return result;
      }

      console.log(`Found ${allResponses.length} media responses for session ${sessionId}`);

      // Create a session folder
      const parentFolderId = hasConsent 
        ? GOOGLE_DRIVE_CONFIG.socialFolderId 
        : GOOGLE_DRIVE_CONFIG.privateFolderId;
        
      const sessionFolderName = `Session_${sessionId.slice(0, 8)}_${new Date().toISOString().split('T')[0]}`;
      const sessionFolderId = await createFolder(sessionFolderName, parentFolderId);
      
      if (!sessionFolderId) {
        result.errors.push('Failed to create session folder');
        return result;
      }

      result.folderId = sessionFolderId;
      console.log(`Created session folder: ${sessionFolderName} (${sessionFolderId})`);

      // Upload each media file
      let uploadedCount = 0;
      for (const response of allResponses) {
        try {
          setUploadProgress(Math.round((uploadedCount / allResponses.length) * 100));
          
          // Download the file from Supabase Storage
          console.log(`Downloading ${response.type} for Q${response.question_number}:`, response.storage_url);
          const fileResponse = await fetch(response.storage_url);
          
          if (!fileResponse.ok) {
            result.errors.push(`Failed to download ${response.type} for question ${response.question_number}`);
            continue;
          }

          const blob = await fileResponse.blob();
          const fileName = `Q${response.question_number}_${response.type}_response.${response.type === 'video' ? 'mp4' : 'webm'}`;

          // Upload to Google Drive
          const metadata = {
            name: fileName,
            parents: [sessionFolderId]
          };

          const form = new FormData();
          form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
          form.append('file', blob);

          const uploadResult = await new Promise<{ success: boolean; fileId?: string; error?: string }>((resolve) => {
            const xhr = new XMLHttpRequest();
            
            xhr.onload = () => {
              if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                resolve({ success: true, fileId: response.id });
              } else {
                resolve({ success: false, error: `Upload failed: ${xhr.statusText}` });
              }
            };

            xhr.onerror = () => {
              resolve({ success: false, error: 'Upload failed due to network error' });
            };

            xhr.open('POST', 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart');
            xhr.setRequestHeader('Authorization', `Bearer ${window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse().access_token}`);
            xhr.send(form);
          });

          if (uploadResult.success) {
            result.uploadedFiles.push(fileName);
            console.log(`Uploaded ${fileName} to Google Drive`);
          } else {
            result.errors.push(`Failed to upload ${fileName}: ${uploadResult.error}`);
          }

          uploadedCount++;
        } catch (error) {
          result.errors.push(`Error processing ${response.type} for question ${response.question_number}: ${error instanceof Error ? error.message : 'Unknown error'}`);
          console.error(`Error processing response:`, error);
        }
      }

      setUploadProgress(100);
      result.success = result.uploadedFiles.length > 0;
      
      console.log(`Session upload complete. Uploaded: ${result.uploadedFiles.length}, Errors: ${result.errors.length}`);
      return result;

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Upload failed';
      result.errors.push(errorMessage);
      return result;
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  }, [authenticate, gapiReady, createFolder]);
  return {
    uploadToGoogleDrive,
    uploadSessionResponsesToDrive,
    isUploading,
    uploadProgress,
    gapiReady
  };
};